
-----------------------------------------------------------------
## to start compiling the assembly:

## Necessarily node >= 20 !!!!

1. npm i  ---to install packages
2. npm run start ---to build the project and run localhost
3. npm run build ---to build a project without running localhost
-----------------------------------------------------------------
