import './components/dinamicHeight.js';
import './components/sliders.js';
// import './components/gallery.js';
import './components/global.js';
// import './components/form-validate.js';
import './components/fancybox.js';
import './components/acc.js';
// import './components/tabs.js';
import './components/burger.js';
import './components/replaceEl.js';
import './components/download.js';
// import './functions/scripts/range.js';

