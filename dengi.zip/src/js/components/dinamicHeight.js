import vars from '../_vars.js';
import {elementHeight, elementWidth} from '../functions/customFunctions.js';

const {footer,header} = vars;

setTimeout( function (){
    elementHeight(header, 'header-height');
}, 0)




